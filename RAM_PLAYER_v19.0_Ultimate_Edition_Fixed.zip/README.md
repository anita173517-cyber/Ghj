# RAM PLAYER v19.0 — AMOLED 3D Edition (Build 190)

**Package ID:** `com.harindra.iptvpro` (`versionCode = 190`, `versionName = "19.0"`)  
**Engine:** AndroidX Media3 `1.11.1` • Direct-RAM Zero-Disk Streaming • 512MB RAM Smart TV Guard

## Key Features in v19.0
- **True AMOLED 3D Design System**: Pure AMOLED Black (`#000000`), Dark Charcoal (`#0B0F19`), Brushed Titanium (`#CBD5E1`), Electric Cyan (`#38BDF8`), and Violet (`#8B5CF6`).
- **3D Launcher & TV Banner Integration**: Custom 3D metallic RAM PLAYER icon across `mipmap-mdpi` to `mipmap-xxxhdpi` and `drawable-xhdpi/tv_banner_ram_player.png`.
- **Complete Profile Isolation**: Per-profile Favorites, Watch History, Continue Watching, Watchlists, Playback Progress, Custom Groups, Hidden Channels, Channel Blacklist, Parental PIN/Locks, Home Rows, Sidebar Order, and Remote Shortcuts.
- **Voice Search**: Android TV `RecognizerIntent` microphone search with graceful fallback when no speech recognizer is installed.
- **Channel Blacklist (Separate from Hide/Unhide)**: Persistent per-profile channel blocking, management modal, and one-tap unblock.
- **Playlist Auto-Refresh Scheduler**: Configurable interval (`OFF / 6h / 12h / 24h / 72h`), Refresh-on-Startup toggle, Manual Refresh, Cancel, and Live Status tracking.
- **Home Rows & Sidebar Customization**: Show/hide and reorder Home Hub rows and navigation bar icons per profile (keeping Home & Settings accessible).
- **Remote-Key Customization & Player Lock**: Configurable Long-Press OK + Red/Green/Yellow/Blue remote color keys, plus Player Lock to prevent accidental button presses.
- **Audio/Subtitle Controls & Hardware Detection**: Real-time Subtitle Delay (`0ms–3000ms`), Audio Delay preference (`0ms–500ms`), Audio Loudness Boost, `AudioCapabilities` passthrough detection (`AC3/E-AC3/DTS/TrueHD`), and `ColorInfo` / `Display.HdrCapabilities` HDR detection (zero fake HDR claims).
- **512MB-RAM-Safe Channel Preview, Sleep Timer & External Player**: Metadata + EPG preview card, `15m–90m / Custom / OFF` Sleep Timer, and `Intent.ACTION_VIEW` external player launcher.
- **Secure SXBK_V19 Backup & Restore**: Versioned JSON validation, explicit restore confirmation dialog, and atomic failure-safe preservation.
- **English + Hindi Localization**: `values/strings.xml` and `values-hi/strings.xml`, including Legal Disclaimer in `About`.

## Verification & Build
Run offline verification:
```bash
python3 scripts/verify_project.py
```
Build Debug & Release APKs via GitHub Actions (`.github/workflows/build_apk.yml`) or Android Studio with JDK 17 + Android SDK 36 + Gradle 8.13.
